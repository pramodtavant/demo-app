(function () {

    /**
     * @class Viewer
     * @description Creates the object that manages 3D scenes.
     * @param {string} canvasId - Id of the canvas where the 3D scene will be rendered => you should add the choice between Id and canvas itself.
     */
    Viewer = function (canvasId) {

        //Gets the canvas.
        this.canvas = document.querySelector("#" + canvasId);

        //Creates the 3D engine.
        this.engine = new BABYLON.Engine(this.canvas, true);

        //Adds event to resize 3D scene when the window is resized.
        window.addEventListener("resize", function () {
            this.engine.resize();
        });

    };


    /**
     * @function createScene
     * @description Creates the 3D scene with lights, camera, etc.
     * @param {object} params 
     * @param {object} params.heightmap
     * @param {string} params.heightmap.url - URL (relative or absolute) of the image used for the 3D-model.
     * @param {number} params.heightmap.width - Width in pixel of the 3D model image.
     * @param {number} params.heightmap.height - Height in pixel of the 3D model image.
     * @param {number} params.heightmap.subdivisions - Increase or decrease the accuracy of the model.
     * @param {number} params.heightmap.minHeight - 0 by default.
     * @param {number} params.heightmap.maxHeight - difference between minimum and maximum altitude (approximatively).
     * @param {number} params.texture - URL (relative or absolute) of the image used for the texture.
     */
    Viewer.prototype.createScene = function (params) {

        if (params) {

            this.set = params.set;
            this.numField = params.numField;

            var scene = new BABYLON.Scene(this.engine);
            scene.enablePhysics();
            scene.gravity = new BABYLON.Vector3(0, -9.81, 0);
            scene.clearColor = new BABYLON.Color4(0, 0, 0, 0.1);
            scene.collisionsEnabled = true;

            // Light
            var spot = new BABYLON.PointLight("spot" + this.canvas.id, new BABYLON.Vector3(0, 100, 0), scene);
            spot.diffuse = new BABYLON.Color3(10, 10, 10);
            spot.specular = new BABYLON.Color3(0, 0, 0);

            // Camera
            var camera = new BABYLON.ArcRotateCamera("Camera", -(Math.PI / 2), (Math.PI / 2) * 0, 300, BABYLON.Vector3.Zero(), scene);
            camera.ellipsoid = new BABYLON.Vector3(1, 1, 1);
            camera.applyGravity = true;
            camera.checkCollisions = true;
            camera.attachControl(this.canvas, true);

            // Ground
            var groundMaterial = new BABYLON.StandardMaterial("ground" + this.canvas.id, scene);
            groundMaterial.diffuseTexture = new BABYLON.Texture(params.texture, scene);
            groundMaterial.diffuseTexture.hasAlpha = true;

            var sol = BABYLON.Mesh.CreateGround("sol" + this.canvas.id, params.heightMap.width, params.heightMap.height, 1, scene);

            sol.setPositionWithLocalVector(new BABYLON.Vector3(0, -10, 0));


            this.ground = BABYLON.Mesh
                .CreateGroundFromHeightMap("ground" + this.canvas.id,
                    params.heightMap.url,
                    params.heightMap.width,
                    params.heightMap.height,
                    params.heightMap.subdivisions,
                    params.heightMap.minHeight,
                    params.heightMap.maxHeight,
                    scene,
                    true,
                    null);
            this.ground.material = groundMaterial;
            this.ground.material.backFaceCulling = false;
            this.ground.checkCollisions = true;

            var g = this.ground;

            var beforeRenderFunction = function () {
                // Camera
                if (camera.beta < 0.1)
                    camera.beta = 0.1;
                else if (camera.beta > (Math.PI / 2) * 0.9)
                    camera.beta = (Math.PI / 2) * 0.9;
            };

            scene.registerBeforeRender(beforeRenderFunction);

            var img = document.getElementById('rose');
            this.engine.runRenderLoop(function () {

                scene.render();

                if (img) {
                    var acr = scene.cameras[0].alpha + Math.PI / 2;
                    img.style.transform = 'rotate(' + acr * 180 / Math.PI + 'deg)';
                }
            });

            return scene;

        } else {

            return null;
        }

    };


    /**
     * @function changeScale
     * @description Modify the scale of the ground to accentuate the ground effect.
     * @param {number} scale - The new scale.
     */
    Viewer.prototype.changeScale = function (scale) {

        this.ground.scaling.y = scale;

    };


    /**
     * @function modifyTexture
     * @description Changes the texture of the ground. It is used to keep the same ground, but to apply another image on.
     * @param {string} path - Path of the image used as texture.
     */
    Viewer.prototype.modifyTexture = function (path) {

        var texture = new BABYLON.Texture(path, this.engine.scenes[0]);

        texture.hasAlpha = true;

        this.ground.material.diffuseTexture = texture;

    };

})();