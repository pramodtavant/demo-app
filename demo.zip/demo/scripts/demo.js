$(document).ready(function(){

    //Creates the 3D scene with the params given by the method getParams.
    demo.load(demo.getParams());

});

var demo = {

    //The API object to manage the 3D scene.
    viewer: null,

    //Creates the scene with given parameters
    load: function (params) {

        //Creates viewer.
        demo.viewer = new Viewer('renderCanvas');

        //Creates the new 3D scene.
        var scene = demo.viewer.createScene(params);

        //Avoid mousewheel event on the page itself.
        document.getElementById("renderCanvas").onmousewheel = function (event) {
            event.preventDefault();
        };       

    },

    //Calls API to change the scale.
    changeScale: function (scale) {      
        demo.viewer.changeScale(scale);
    },

    //Calls API to modify texture.
    modifyTexture: function (path) {
        demo.viewer.modifyTexture(path);
    },

    //Returns the params to create a new scene.
    //This object will be given by the client application.
    //See in geosys.viewer.3d.js the createScene to have details about the parameters.
    getParams: function () {

        return {
            texture: './data/NDVI_20151107.png',
            heightMap: {
                url: './data/dem.jpg',
                width: 271,
                height: 214,
                subdivisions: 25,
                minHeight: 0,
                maxHeight: 10
            }
        };
     
    }
};