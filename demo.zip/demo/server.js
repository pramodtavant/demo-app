const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

//--------------------------------------------Serves demo files
app.use('/scripts', express.static(__dirname + '/scripts'));
app.use('/css', express.static(__dirname + '/css'));
app.use('/data', express.static(__dirname + '/data'));

app.use('/', (req, res, next) => {
    res.sendFile(path.resolve(__dirname + '/demo.html'));
});








//--------------------------------------------Manages errors 
app.use('/', function errorHandler(err, req, res, next) {

    if (res.headersSent) {
        return next(err);
    }

    res.status(500);

    res.json({
        error: err.message
    });
});

app.listen(8000);